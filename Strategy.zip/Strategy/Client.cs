﻿using System;

namespace Strategy
{
    class People

    {
        static void Main(string[] args)
        {
            Console.WriteLine("Что вам рассказать?");
            string task = Console.ReadLine();
            Console.WriteLine("Какую сложность?");
            string difficulty = Console.ReadLine();

            if (task == "стих")
            {
                Verse_ verse_ = new Verse_();
                switch (difficulty)
                {
                    case "легко":
                        verse_.SetForChildren(new EasyTask());
                        verse_.Write();
                        break;
                    case "средне":
                        verse_.SetForChildren(new MediumTask());
                        verse_.Write();
                        break;
                    case "сложно":
                        verse_.SetForChildren(new DifficultTask());
                        verse_.Write();
                        break;
                }
            }
            else if (task == "стишок")
            {
                Verse verse = new Verse();
                switch (difficulty)
                {
                    case "легко":
                        verse.SetForChildren(new EasyTask());
                        verse.Write();
                        break;
                    case "средне":
                        verse.SetForChildren(new MediumTask());
                        verse.Write();
                        break;
                    case "сложно":
                        verse.SetForChildren(new DifficultTask());
                        verse.Write();
                        break;
                }
            }
            Console.ReadLine();

        }
    }
}
