﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy
{
    class Verse_
    {
        public Verse_()
        {

        }

        public TasksForChildren taskForChildren { private get; set; }
        public void Write()
        {
            taskForChildren.Write();
        }

        public void SetForChildren(TasksForChildren tfc)
        {
            this.taskForChildren = tfc;
        }
    }
}
