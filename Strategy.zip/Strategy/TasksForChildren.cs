﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy
{
    interface TasksForChildren
    {
        void Write();
    }
}
