﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy
{
    class MediumTask : TasksForChildren
    {
        public void Write()
        {
            Console.WriteLine("— Пуговки, послушайте! —\n" +
                              "Говорит вам Лушенька.\n" +
                              "Вы меня не подведите,\n" +
                              "Прямо в дырки попадите.\n" +
                              "Застегнут вас пальчики —\n" +
                              "Маленькие мальчики.\n" +
                              "А попозже не зевайте\n" +
                              "И из дырок вылезайте.\n" + "\n" +
                "Уровень развития 3-4 года.\nУровень сложности: средний.\n");
        }
    }
}
