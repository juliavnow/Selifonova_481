﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy
{
    class EasyTask : TasksForChildren
    {
        public void Write()
        {
            Console.WriteLine("У мышонка целый пир,\n" +
                "Ест мышонок вкусный сыр.\n" +
                "Маму просит:«Пи - пи - пи!\n" +
                "Сыра мне еще купи!»\n" + "\n" +
                "Уровень развития 2-3 года.\nУровень сложности: легко.\n");
        }
    }
}
