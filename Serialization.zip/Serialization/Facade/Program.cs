﻿namespace Serialization
{
    public class Serialization
    {
        Serializer serializer;
        DateData data1;
        NameData data2;
        TaskData data3;

        public Serialization(DateData d1, NameData d2, TaskData d3, Serializer s)
        {
            data1 = d1;
            data2 = d2;
            data3 = d3;

            serializer = s;
        }
        public void SerializeOptions()
        {
            serializer.Serialize(data1.GetDate(), "date");
            serializer.Serialize(data2.GetString(), "name");
        }
        public void SerializeAll()
        {
            serializer.Serialize(data1.GetDate(), "date");
            serializer.Serialize(data2.GetString(), "name");
            serializer.Serialize(data3.GetTask(), "task");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Serialization serialization = 
                new Serialization(new DateData(), new NameData(), new TaskData(), new JSONSerializer());

            serialization.SerializeOptions();
            serialization.SerializeAll();
        }
    }
}
