﻿using Newtonsoft.Json;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Serialization
{
    public abstract class Serializer
    {
        public abstract void Serialize<T>(T data, string fileName);
    }

    //JSON
    public class JSONSerializer : Serializer
    {
        public override void Serialize<T>(T data, string fileName)
        {
            using (StreamWriter su = new StreamWriter($"D:\\Юле\\учеба\\Портенко\\На проверку\\СЕРИАЛИЗАЦИИ\\Serialization\\{fileName}.json", true))
            using (JsonWriter user = new JsonTextWriter(su))
            {
                JsonSerializer ser = new JsonSerializer();
                ser.Serialize(user, data);
            }
        }
    }

    //XML
    public class XMLSerializer : Serializer
    {
        public override void Serialize<T>(T data, string fileName)
        {
            // создаем объект XmlSerializer
            XmlSerializer formatter = new XmlSerializer(typeof(T));
            // получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream($"D:\\Юле\\учеба\\Портенко\\На проверку\\СЕРИАЛИЗАЦИИ\\Serialization\\{fileName}.xml", FileMode.Append))
            {
                formatter.Serialize(fs, data);
            }
        }
    }

    //Binary
    public class BinarySerializer : Serializer
    {
        public override void Serialize<T>(T data, string fileName)
        {
            // создаем объект BinaryFormatter
            BinaryFormatter formatter = new BinaryFormatter();
            // получаем поток, куда будем записывать сериализованный объект
            using (FileStream fs = new FileStream($"D:\\Юле\\учеба\\Портенко\\На проверку\\СЕРИАЛИЗАЦИИ\\Serialization\\{fileName }.dat", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, data);
            }
        }
    }
}
