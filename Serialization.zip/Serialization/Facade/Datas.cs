﻿using System;

namespace Serialization
{
    public class DateData
    {
        public DateTime GetDate()
        {
            return DateTime.Now;
        }
    }

    public class TaskData
    {
        public Task GetTask()
        {
            return new Task("Кабинет: ", 25, "Полить цветы");
            //return new Task("Кабинет: ", 17, "Включить сигнализацию перед уходом");
            //return new Task("Кабинет: ", 3, "Закрыть окна после проветривания");
            //return new Task("Кабинет: ", 11, "Выключить питание и закрыть кабинет");
            //return new Task("Кабинет: ", 16, "Подготовить кабинет к конференции");
            //return new Task("Кабинет: ", 14, "Починить проектор");
            //return new Task("Кабинет: ", 8, "Закупить чай и кофе на общую кухню");
            //return new Task("Кабинет: ", 4, "Провести проверку документов");
            //return new Task("Кабинет: ", 11, "Заменить картридж в принтере");
        }
    }

    public class Task
    {
        public string Text1 { get; set; }
        public int Count { get; set; }
        public string Text2 { get; set; }
        public DateTime CreationDate { get; set; }

        public Task(string text1, int count, string text2)
        {
            Text1 = text1;
            Count = count;
            Text2 = text2;
            CreationDate = DateTime.Now;
        }
    }

    public class NameData
    {
        public string GetString()
        {
            return "Иванова Ольга Николаевна";
            //return "Горцев Михаил Александрович";
            //return "Петров Николай Евгеньевич";
            //return "Кузьмина Ольга Петровна";
            //return "Морозова Лариса Викторовна";
            //return "Балашов Кирилл Олегович";
            //return "Кабанова Ирина Владимировна";
            //return "Шершнев Никита Федерович";
            //return "Александрова Кристина Борисовна";
        }
    }
}
